import java.awt.image.BufferedImage;
import javax.imageio.ImageIO; 
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.awt.Graphics2D;

public class HideMessage{
  public static void main(String args[]) {
    //Aufrufen der Methode mit Eingabe- und Ausgabepfad
    hideMessage("2parrot.png", "parrotShrek.png", "shrek123.txt");
  }
  public static void hideMessage(String inputPath, String outputPath, String messagePath){
    try {
      //Importieren des Bildes und des Textes
      BufferedImage input = ImageIO.read(new File(inputPath));
      BufferedImage inputImg = new BufferedImage(input.getWidth(), input.getHeight(), BufferedImage.TYPE_INT_ARGB);
      Graphics2D g = inputImg.createGraphics();
      g.drawImage(input, 0, 0, null);
      g.dispose();
      
      String message = "";
      BufferedReader br = new BufferedReader(new FileReader(new File(messagePath)));
      String available;
      while ((available = br.readLine()) != null) {
        message += available;
        message += "\n";         
      } 
      //Backslash als Markierung, dass die Nachricht zuende ist
      message += "\\";
      
      int width = inputImg.getWidth();
      int height = inputImg.getHeight();
      //Falls Nachricht zu lang, beende Programm
      if (message.length()*2 > width*height) {
        System.out.println("Die Nachricht ist zu lang für das Bild. Die Anzahl der Pixel muss doppelt so groß sein wie die Anzahl der Zeichen.");
        System.exit(0);
      }
      //über jedes Pixel iterieren, x steht für das Pixel, x/2 für den zu codierenden char
      for (int x = 0; x/2 < message.length(); x+=2) {
        //Farbwerte der nächsten 2 Pixel auslesen
        int[] coords1 = numToCoords(x, width);
        int[] coords2 = numToCoords(x+1, width);
        int pixel1 = inputImg.getRGB(coords1[0], coords1[1]);
        int pixel2 = inputImg.getRGB(coords2[0], coords2[1]);
        int c = (int) message.charAt(x/2);
        //letztes Bit pro Farbkanal auf 0 setzen
        pixel1 = pixel1 & 0xFEFEFEFE;
        pixel2 = pixel2 & 0xFEFEFEFE;
        
        //relevantes Bit des char isolieren und an richtige Stelle verschieben, dann per | mit dem Frabwert kombinieren
        pixel1 = (((pixel1 | ((c & 0x80) << 17)) | ((c & 0x40) << 10)) | ((c & 0x20) << 3)) | ((c & 0x10) >>> 4);
        pixel2 = ((((pixel2 | ((c & 0x8) << 21))) | ((c & 0x4) << 14)) | ((c & 0x2) << 7)) | (c & 0x1);
        //Neue Farbwerte setzen
        inputImg.setRGB(coords1[0], coords1[1], pixel1);
        inputImg.setRGB(coords2[0], coords2[1], pixel2);
      }
      //Speichern des veränderten Bildes im Ausgabepfad
      ImageIO.write(inputImg, "png", new File(outputPath));
      System.out.println("Neues Bild wurde gespeichert als " + outputPath);
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Berechne aus Zahl und Spaltenzahl die Koordinaten des Pixels
  public static int[] numToCoords(int n, int width){
    int[] a = new int[2];
    a[0] = n%width;
    a[1] = n/width;
    return a;
  }
}


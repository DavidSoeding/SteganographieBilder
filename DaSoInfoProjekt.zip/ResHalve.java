import java.awt.image.BufferedImage;
import javax.imageio.ImageIO; 
import java.io.File;

public class ResHalve{
  public static void main(String args[]) {
    //Aufruf der Methode mit Eingabe- und Ausgabepfad
    halveRes("parrot.png", "o3.png");
  }
  
  public static void halveRes(String inputPath, String outputPath){
    try {
      //PNG-Datei wird importiert
      BufferedImage inputImg = ImageIO.read(new File(inputPath));
      
      //Wenn Höhe ungerade, runde auf und fülle neue Reihe mit Farbwerten der vorletzten Reihe
      if (inputImg.getHeight()%2 != 0){
        int newHeight = inputImg.getHeight() + inputImg.getHeight()%2;
        BufferedImage temp = new BufferedImage(inputImg.getWidth(), newHeight, BufferedImage.TYPE_4BYTE_ABGR);
        for (int x = 0; x < inputImg.getWidth(); x++) {
          for (int y = 0; y< newHeight; y++) {
            if (y < inputImg.getHeight()) {
              temp.setRGB(x, y, inputImg.getRGB(x, y));
            }else {
              temp.setRGB(x, y, inputImg.getRGB(x, y-1));
            }
          }
        }
        inputImg = temp;
      }
      
      //Wenn Breite ungerade, runde auf und fülle neue Spalte mit Farbwerten der vorletzten Spalte
      if (inputImg.getWidth()%2 != 0){
        int newWidth = inputImg.getWidth() + inputImg.getWidth()%2;
        BufferedImage temp = new BufferedImage(newWidth, inputImg.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);
        for (int x = 0; x < newWidth; x++) {
          for (int y = 0; y< temp.getHeight(); y++) {
            if (x < inputImg.getWidth()) {
              temp.setRGB(x, y, inputImg.getRGB(x, y));
            }else {
              temp.setRGB(x, y, inputImg.getRGB(x-1, y));  
            }
          }
        }
        inputImg = temp;
      }
      
      //Erstelle neues Bild mit der Hälfte der Dimensionen der Eingabe
      BufferedImage outputImg = new BufferedImage(inputImg.getWidth()/2, inputImg.getHeight()/2, BufferedImage.TYPE_4BYTE_ABGR);
      
      //Itteriere in zweier-Schritten über das Bild und bilde den Mittelwert von jedem vierer-Pixel-Block
      for (int x = 0; x < inputImg.getWidth(); x+=2) {
        for (int y = 0; y < inputImg.getHeight(); y+=2) {
          int pixel1 = inputImg.getRGB(x, y);
          int pixel2 = inputImg.getRGB(x+1, y);
          int pixel3 = inputImg.getRGB(x, y+1);
          int pixel4 = inputImg.getRGB(x+1, y+1);
          
          //Werte sind 32bits, jeder Farbkanal(ARGB) hat 8 bits
          //Verschiebe die Bits nach rechts, sodass der jeweilige Farbkanal in den rechten 8 bits steht, & 0xff damit alle Bits außer den letzten 8 den Wert 0 haben
          int avgAlpha = ((pixel1 >> 24) & 0xff) + ((pixel2 >> 24) & 0xff) + ((pixel3 >> 24) & 0xff) + ((pixel4 >> 24) & 0xff);
          int avgR = ((pixel1 >> 16) & 0xff) + ((pixel2 >> 16) & 0xff) + ((pixel3 >> 16) & 0xff) + ((pixel4 >> 16) & 0xff);
          int avgG = ((pixel1 >> 8) & 0xff) + ((pixel2 >> 8) & 0xff) + ((pixel3 >> 8) & 0xff) + ((pixel4 >> 8) & 0xff);
          int avgB = (pixel1 & 0xff) + (pixel2 & 0xff) + (pixel3 & 0xff) + (pixel4 & 0xff);
          
          avgAlpha /= 4;
          avgR /= 4;
          avgG /= 4;              
          avgB /= 4;
          
          //Füge einzelne Farbkanäle zu einem int zusammen
          int color = (avgAlpha << 24) | (avgR << 16) | (avgG << 8) | avgB;
          
          outputImg.setRGB(x/2, y/2, color);
        }

      }
      
      //Speichere die Ausgabe als PNG-Datei
      ImageIO.write(outputImg, "png", new File(outputPath));
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}
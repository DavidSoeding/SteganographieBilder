import java.awt.image.BufferedImage;
import javax.imageio.ImageIO; 
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;

public class ShowMessage{
  public static void main(String args[]) {
    //Aufrufen der Methode mit Eingabe- und Ausgabepfad
    showMessage("parrotShrek.png", "shrek123OUT.txt");
  }
  public static void showMessage(String inputPath, String outputPath){
    try {
      //Importieren des Bildes
      BufferedImage inputImg = ImageIO.read(new File(inputPath));
      String message = "";
      
      int width = inputImg.getWidth();
      int height = inputImg.getHeight();
      
      //über jedes Pixel iterieren, x steht für das Pixel, x/2 für den zu codierenden char
      int x=0;
      do {
        //Farbwerte der nächsten 2 Pixel auslesen
        int[] coords1 = numToCoords(x, width);
        int[] coords2 = numToCoords(x+1, width);
        int pixel1 = inputImg.getRGB(coords1[0], coords1[1]);
        int pixel2 = inputImg.getRGB(coords2[0], coords2[1]);
        //relevantes Bit des char isolieren und an richtige Stelle verschieben, dann per | mit dem Frabwert kombinieren
        pixel1 = ((pixel1 & 0x1000000) >>> 17) | ((pixel1 & 0x10000) >>> 10) | ((pixel1 & 0x100) >>> 3) | ((pixel1 & 0x1) << 4);
        pixel2 = ((pixel2 & 0x1000000) >>> 21) | ((pixel2 & 0x10000) >>> 14) | ((pixel2 & 0x100) >>> 7) | (pixel2 & 0x1);
        
        char c = (char) (pixel1 | pixel2);
        message += c;
        x +=2;
      }while (message.charAt(message.length()-1) != '\\' && x < width*height-2);
      //Abbruch-Zeichen wieder entfernen
      message = message.substring(0, message.length()-1);
      FileWriter writer = new FileWriter(outputPath);
      System.out.println("Die Nachricht wurde erfolgreich als " + outputPath + " gespeichert.");
      writer.write(message);
      writer.close();
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
   //Berechne aus Zahl und Spaltenzahl die Koordinaten des Pixels 
  public static int[] numToCoords(int n, int width){
    int[] a = new int[2];
    a[0] = n%width;
    a[1] = n/width;
    return a;
  }
}


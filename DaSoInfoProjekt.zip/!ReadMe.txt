ResHalve.java
-Das Ursprüngliche Ziel des Projektes

HiddenMessageTest.java
-Programm, welches die Farbwerte mit Zufallwerten ersetzt, um die Veränderung im Bild zu erforschen

HideMessage.java
-Das Haupt-Programm, welches Nachrichten in Bildern versteckt

ShowMessage.java
-Liest versteckte Nachrichten aus Bildern wieder aus


2parrot.png
-Das Eingabe-Bild, mit dem das finale Ergebnis erziehlt wurde

shrek123.txt
-Die Nachricht, mit dem das finale Ergebnis erziehlt wurde

parrotShrek.png
-Die Ausgabe für shrek123.txt und 2parrot.png
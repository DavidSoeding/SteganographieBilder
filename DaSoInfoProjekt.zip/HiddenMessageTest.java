import java.awt.image.BufferedImage;
import javax.imageio.ImageIO; 
import java.io.File; 
import java.util.concurrent.ThreadLocalRandom;

public class HiddenMessageTest{
  public static void main(String args[]) {
    //Aufrufen der Methode mit Eingabe- und Ausgabepfad
    hideMessage("parrot.png", "parrotTestO.png");
  }
  
  public static void hideMessage(String inputPath, String outputPath){
    try {
      //Importieren des Bildes
      BufferedImage inputImg = ImageIO.read(new File(inputPath));
      
      //Für jeden Pixel werden die letzten 3 bits erst auf null gesetzt und dann per | mit einem 32bit Zufalls-Integer kombiniert
      for (int x = 0; x < inputImg.getWidth(); x++) {
        for (int y = 0; y < inputImg.getHeight(); y++) {
          int color = inputImg.getRGB(x, y);
          int randomNum = ThreadLocalRandom.current().nextInt();
          color = (color & 0xF8F8F8F8) | (randomNum & ~0xF8F8F8F8);
          inputImg.setRGB(x, y, color);
        }
      }
      //Speichern des veränderten Bildes im Ausgabepfad
      ImageIO.write(inputImg, "png", new File(outputPath));
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}